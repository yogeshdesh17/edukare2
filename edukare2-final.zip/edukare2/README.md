# Edukare Academy — Website

**Built for:** Edukare Academy, Kharadi, Pune  
**Tech Stack:** Next.js 14 + Static Export (Vercel-ready)  
**Status:** Production build ready ✅

---

## Pages Included
- `/` — Home (hero, stats, courses, KYC, why us, toppers, testimonials, activities, faculty preview, CTA, enquiry form)
- `/courses` — All courses listing with Arjuna vs Chanakya comparison
- `/courses/[id]` — Individual course pages (6 courses, dynamic)
- `/results` — All toppers: 10 board toppers + 8 CET toppers
- `/faculty` — Director + all 14 faculty members
- `/kyc` — KYC Know Your Child explainer with sample report
- `/admissions` — Process, dates, batch comparison, booking form
- `/fees` — Complete transparent fee structure (all batches)
- `/about` — Founder story, logo meaning, mission, activities
- `/blog` — 5 articles at launch with category filter
- `/contact` — Form, map, social links
- `/privacy` — Privacy & refund policy

---

## Quick Start

```bash
npm install
npm run dev        # Development: http://localhost:3000
npm run build      # Production build → generates /out folder
```

---

## Deploy to Vercel (Recommended — Free)

1. Push this folder to GitHub
2. Go to https://vercel.com → "Add New Project"
3. Import your GitHub repo
4. Vercel auto-detects Next.js — click **Deploy**
5. In Vercel dashboard → Settings → Domains → add `edukareacademy.com`
6. Update DNS at your domain registrar: point to Vercel nameservers

**Total cost: ₹0** (Vercel free tier handles institute website traffic easily)

---

## What to Replace (Placeholder Items)

All placeholders are clearly labelled in the UI. Search for `placeholder-note` in the CSS or look for `img-placeholder` divs.

| Item | Where | Action |
|------|--------|--------|
| Faculty photos | `/faculty` page + home faculty section | Replace `<Img emoji="👤">` with `<img src="...">` |
| Director photo | `/about` page | Same as above |
| Hero background | Home hero | Replace `<Img>` in hero-img-main with real classroom photo |
| Activity photos | Home + about | Replace `<Img>` in activities-photos grid |
| Topper photos | `/results` + home toppers | Replace `<Img emoji="👤">` per topper card |
| Google Maps embed | Home + contact | Replace the iframe `src` with your Google Maps embed URL for the exact address |
| Logo | Everywhere | Replace the `📚` emoji in NavLogo and footer with `<img src="/logo.png">` |

---

## Content Updates (Non-technical — via code or future CMS)

| What to update | File | Variable/Section |
|----------------|------|-----------------|
| Phone number | `lib/data.js` | `INSTITUTE.phone` |
| Address | `lib/data.js` | `INSTITUTE.address` |
| Social links | `lib/data.js` | `INSTITUTE.social` |
| Fee structure | `lib/data.js` | `COURSES[].fees` + `app/fees/page.js` |
| Toppers | `lib/data.js` | `TOPPERS` array |
| Faculty | `lib/data.js` | `FACULTY` array |
| Testimonials | `lib/data.js` | `TESTIMONIALS` array |
| Blog posts | `app/blog/page.js` | `POSTS` array |
| Stats (counter numbers) | `lib/data.js` | `INSTITUTE.stats` |

---

## WhatsApp Integration

All enquiry forms open WhatsApp with a pre-filled message to `+91 8530180202`.  
To change the number: update `INSTITUTE.phone` in `lib/data.js`.

---

## Google Fonts

Outfit font is loaded via link tag in `app/layout.js`.  
In the build environment, the font download was skipped but will load normally from any internet-connected server.

